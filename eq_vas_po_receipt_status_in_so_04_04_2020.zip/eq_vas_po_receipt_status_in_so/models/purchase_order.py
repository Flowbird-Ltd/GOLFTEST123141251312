# -*- coding: utf-8 -*-
##############################################################################
#
# Copyright 2019 EquickERP
#
##############################################################################


from odoo import api, fields, models, _


class sale_order(models.Model):
    _inherit = 'sale.order'

    @api.depends('purchase_order_count', 'order_line.purchase_line_ids', 'order_line.purchase_line_ids.order_id', 'order_line.purchase_line_ids.order_id.picking_ids.state')
    def _get_purchase_receipt_status(self):
        for order in self:
            pickings = self.env['stock.picking']
            purchase_line_ids = self.env['purchase.order.line'].sudo().search([('sale_order_id', 'in', order.ids)])
            purchase_order_ids = purchase_line_ids.mapped('order_id')
            picking_ids = purchase_order_ids.mapped('picking_ids')
            receipt_status = False
            picking_status_lst = set(picking_ids.mapped('state'))
            if picking_status_lst:
                if 'cancel' in picking_status_lst and len(set(picking_status_lst)) != 1:
                    picking_status_lst.remove('cancel')
                if all(l == 'draft' for l in picking_status_lst):
                    receipt_status = 'draft'
                if all(l in ('waiting', 'confirmed') for l in picking_status_lst):
                    receipt_status = 'waiting'
                if all(l == 'assigned' for l in picking_status_lst):
                    receipt_status = 'assigned'
                if all(l == 'done' for l in picking_status_lst):
                    receipt_status = 'done'
                if all(l == 'cancel' for l in picking_status_lst):
                    receipt_status = 'cancel'
                if 'done' in picking_status_lst and len(picking_status_lst) > 1:
                    receipt_status = 'partial_received'
                elif 'waiting' in picking_status_lst or 'confirmed' in picking_status_lst:
                    receipt_status = 'waiting'
            order.po_receipt_state = receipt_status

    po_receipt_state = fields.Selection([('draft', 'Draft'),
                                         ('waiting', 'Waiting'),
                                         ('assigned', 'Ready to Receive'),
                                         ('partial_received', 'Partially Received'),
                                         ('done', 'Received'),
                                         ('cancel', 'Cancelled')],
                                         default='draft', copy=False, string="Receipt Status",
                                         compute="_get_purchase_receipt_status", store=True)


class StockRule(models.Model):
    _inherit = 'stock.rule'

    @api.model
    def _prepare_purchase_order_line(self, product_id, product_qty, product_uom, company_id, values, po):
        res = super(StockRule, self)._prepare_purchase_order_line(product_id, product_qty, product_uom, company_id, values, po)
        if values.get('move_dest_ids'):
            if values['move_dest_ids'][0].sale_line_id:
                res.update({'sale_line_id': values['move_dest_ids'][0].sale_line_id.id})
        return res

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: