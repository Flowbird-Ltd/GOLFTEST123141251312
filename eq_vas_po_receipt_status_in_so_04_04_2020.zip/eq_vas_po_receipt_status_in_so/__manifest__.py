# -*- coding: utf-8 -*-
##############################################################################
#
# Copyright 2019 EquickERP
#
##############################################################################

{
    'name' : 'Purchase order Receipt status in Sales Order',
    'category': 'Purchase',
    'version': '1.0',
    'author': 'Equick ERP',
    'description': """
        This Module allows to view the Receipt status in sales order.
    """,
    'summary': 'This Module allows to view the Receipt status in sales order.',
    'depends' : ['base', 'purchase_stock', 'sale_stock', 'sale_management', 'sale_purchase'],
    'license': 'AGPL-3',
    'website': "",
    'data': [
        'views/purchase_order_view.xml',
    ],
    'demo': [],
    'images': ['static/description/main_screenshot.png'],
    'installable': True,
    'auto_install': False,
    'application': False,
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: